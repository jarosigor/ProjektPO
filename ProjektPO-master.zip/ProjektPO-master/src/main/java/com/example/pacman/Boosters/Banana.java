package com.example.pacman.Boosters;

import com.example.pacman.GameComponent;

public class Banana extends GameComponent {
    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
