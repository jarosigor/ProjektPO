package com.example.pacman.Boosters;

import com.example.pacman.GameComponent;

public class Apple extends GameComponent  {
    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
