package com.example.pacman.Ghosts;

public class Ghost {
}
