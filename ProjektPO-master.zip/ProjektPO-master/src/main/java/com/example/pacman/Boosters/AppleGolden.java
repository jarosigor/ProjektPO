package com.example.pacman.Boosters;

public class AppleGolden extends Apple{
}
