package com.example.pacman;

public abstract class GameComponent implements Comparable {
    public GameComponent() {

    }

}
