package com.example.pacman.Boosters;

public class BananaRotten extends Banana {
}
