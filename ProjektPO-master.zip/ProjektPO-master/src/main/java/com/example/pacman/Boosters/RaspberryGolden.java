package com.example.pacman.Boosters;

public class RaspberryGolden extends Raspberry{
}
