package com.example.pacman.Ghosts;

public class GreenGhost {
}
